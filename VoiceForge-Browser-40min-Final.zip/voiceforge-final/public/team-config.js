// CHANGE THESE 10 PASSWORDS BEFORE DEPLOYMENT.
// This is a client-side convenience gate, NOT secure authentication.
window.VOICEFORGE_USERS = {
  "member1": "CHANGE-ME-01",
  "member2": "CHANGE-ME-02",
  "member3": "CHANGE-ME-03",
  "member4": "CHANGE-ME-04",
  "member5": "CHANGE-ME-05",
  "member6": "CHANGE-ME-06",
  "member7": "CHANGE-ME-07",
  "member8": "CHANGE-ME-08",
  "member9": "CHANGE-ME-09",
  "member10": "CHANGE-ME-10"
};
