(function () {
  const users = window.VOICEFORGE_USERS || {};
  const KEY = "voiceforge-session";
  if (sessionStorage.getItem(KEY)) return;

  const style = document.createElement("style");
  style.textContent = `
    #vf-gate{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at top,#18233d 0,#070a12 55%,#05070c 100%);font-family:Inter,Arial,sans-serif;color:#fff}
    #vf-card{width:min(430px,92vw);padding:34px;border-radius:24px;background:rgba(20,27,43,.96);box-shadow:0 30px 100px rgba(0,0,0,.55);border:1px solid rgba(255,255,255,.12)}
    #vf-card h1{margin:0 0 7px;font-size:29px}.vf-sub{color:#aeb9ce;margin-bottom:24px;line-height:1.5}
    #vf-card input{width:100%;box-sizing:border-box;margin:7px 0;padding:14px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:#0b101b;color:#fff;font-size:15px;outline:none}
    #vf-card input:focus{border-color:#806cff}
    #vf-card button{width:100%;margin-top:12px;padding:14px;border:0;border-radius:12px;background:#7657ff;color:white;font-weight:800;cursor:pointer;font-size:15px}
    #vf-error{color:#ff9aa5;min-height:22px;margin-top:10px;font-size:13px}
    .vf-note{font-size:12px;color:#7f8ba1;margin-top:17px;line-height:1.45}
  `;
  document.head.appendChild(style);
  const gate = document.createElement("div");
  gate.id = "vf-gate";
  gate.innerHTML = `
    <div id="vf-card">
      <h1>🎙️ VoiceForge</h1>
      <div class="vf-sub">Private team voice studio<br>Long scripts • Browser AI • 40-minute workflow</div>
      <input id="vf-user" placeholder="Username" autocomplete="username">
      <input id="vf-pass" type="password" placeholder="Password" autocomplete="current-password">
      <button id="vf-login">Sign in</button>
      <div id="vf-error"></div>
      <div class="vf-note">Audio processing runs on the user's computer. Use only voices you have permission to clone.</div>
    </div>`;
  document.body.appendChild(gate);
  const login = () => {
    const u = document.getElementById("vf-user").value.trim();
    const p = document.getElementById("vf-pass").value;
    if (Object.prototype.hasOwnProperty.call(users, u) && users[u] === p) {
      sessionStorage.setItem(KEY, u);
      gate.remove();
    } else {
      document.getElementById("vf-error").textContent = "Invalid username or password.";
    }
  };
  document.getElementById("vf-login").onclick = login;
  document.getElementById("vf-pass").addEventListener("keydown", e => { if (e.key === "Enter") login(); });
  document.getElementById("vf-user").focus();
})();
