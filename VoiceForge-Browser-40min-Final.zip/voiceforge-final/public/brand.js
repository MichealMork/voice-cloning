(function () {
  const add = () => {
    if (document.getElementById('vf-brand')) return;
    const bar = document.createElement('div');
    bar.id = 'vf-brand';
    bar.innerHTML = '<strong>🎙️ VoiceForge</strong><span>40-minute browser voice studio</span><button id="vf-logout">Logout</button>';
    const css = document.createElement('style');
    css.textContent = '#vf-brand{position:fixed;left:14px;right:14px;top:10px;z-index:9999;display:flex;align-items:center;gap:12px;padding:10px 14px;border:1px solid rgba(255,255,255,.1);border-radius:14px;background:rgba(8,12,21,.82);backdrop-filter:blur(12px);color:#fff;font:13px Inter,Arial,sans-serif;box-shadow:0 10px 35px rgba(0,0,0,.2)}#vf-brand span{color:#9ba8bd}#vf-brand button{margin-left:auto;border:1px solid rgba(255,255,255,.14);border-radius:9px;background:transparent;color:#fff;padding:7px 11px;cursor:pointer}';
    document.head.appendChild(css); document.body.appendChild(bar);
    document.getElementById('vf-logout').onclick = () => { sessionStorage.removeItem('voiceforge-session'); location.reload(); };
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', add); else add();
})();
