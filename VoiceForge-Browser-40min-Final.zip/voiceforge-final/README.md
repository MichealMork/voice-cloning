# VoiceForge Browser — 40 Minute Voice Studio

A free, static deployment wrapper around the open-source browser F5-TTS implementation.
The AI runs locally in each user's browser using WebGPU/WASM; there is no TTS server in this project.

## What you get
- Voice cloning from a short reference clip
- Long-script generation with the upstream app's chunking/progress pipeline
- Intended for long recordings, including ~40-minute scripts
- Local browser processing and local generation history
- 10-member convenience login gate
- GitHub Pages deployment with one GitHub Action

## Easiest setup

1. Create a **public GitHub repository**.
2. Upload everything from this folder into the repository root.
3. Before deploying, edit `public/team-config.js` and replace the 10 placeholder passwords.
4. Push to the `main` branch.
5. Open GitHub → **Actions** and wait for `Build and Deploy VoiceForge Browser` to finish.
6. Open GitHub → **Settings → Pages**. The workflow publishes the site.

No Hugging Face Space, API key, paid GPU, or paid TTS API is required.

## Browser requirements

Use a recent Chrome/Edge browser on a reasonably powerful computer. WebGPU is recommended. The first visit downloads the model files; later visits can reuse the browser cache.

Because inference is local, **10 people can use the website independently** without sharing one server GPU. Each person's computer does the work.

## 40-minute reality check

The application can accept long scripts and the upstream F5-TTS web implementation contains text chunking/inference orchestration. A 40-minute final recording is therefore a supported *workflow*, but generation time and whether a particular machine can complete it depend on the user's hardware, browser memory, model settings, and script length. Test a 2–5 minute script first, then a longer one.

## 10-member login

`public/team-config.js` contains 10 usernames and passwords. This is only a **client-side convenience gate**. It is not secure authentication: the credentials are shipped to the browser. Do not use it to protect confidential data.

## Voice rights

Only clone voices you own or have permission to use.

## Upstream project

This wrapper builds the public browser F5-TTS project at deployment time:
https://github.com/nsarang/voice-cloning-f5-tts

The upstream project documents browser-local F5-TTS inference, WebGPU/WASM, 5–10 second reference audio, model caching, and text chunking/progress support.
